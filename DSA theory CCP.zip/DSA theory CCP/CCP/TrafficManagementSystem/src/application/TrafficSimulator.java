// Traffic Simulation - Asynchronous Multi-Intersection with Queue Trend Chart
package application;

import javafx.animation.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.*;

class Vehicle implements Comparable<Vehicle> {
    String id;
    boolean isEmergency;
    int arrivalTime;
    Circle shape;

    Vehicle(String id, boolean isEmergency, int arrivalTime) {
        this.id = id;
        this.isEmergency = isEmergency;
        this.arrivalTime = arrivalTime;
        this.shape = new Circle(6, isEmergency ? Color.RED : Color.BLUE);
        shape.setEffect(new DropShadow(5, Color.BLACK));
    }

    public int compareTo(Vehicle other) {
        return Boolean.compare(other.isEmergency, this.isEmergency);
    }

    public String toString() {
        return (isEmergency ? "[EMERGENCY] " : "") + id;
    }
}

class Intersection {
    String name;
    Queue<Vehicle> normalQueue = new LinkedList<>();
    PriorityQueue<Vehicle> emergencyQueue = new PriorityQueue<>();
    TrafficLight trafficLight = new TrafficLight();
    HBox laneBox = new HBox(5);

    Intersection(String name) {
        this.name = name;
        laneBox.setStyle("-fx-background-color: #eeeeee; -fx-padding: 10; -fx-border-color: gray; -fx-border-width: 2;");
    }

    void enqueueVehicle(Vehicle v) {
        if (v.isEmergency) emergencyQueue.add(v);
        else normalQueue.add(v);
        Platform.runLater(() -> {
            laneBox.getChildren().add(v.shape);
            animateVehicleEntry(v.shape);
        });
    }

    List<Vehicle> processTraffic() {
        List<Vehicle> cleared = new ArrayList<>();
        int processed = 0;
        while (!emergencyQueue.isEmpty() && processed < 3) {
            Vehicle v = emergencyQueue.poll();
            cleared.add(v);
            animateExit(v.shape);
            processed++;
        }
        while (!normalQueue.isEmpty() && processed < 3) {
            Vehicle v = normalQueue.poll();
            cleared.add(v);
            animateExit(v.shape);
            processed++;
        }
        return cleared;
    }

    int getQueueSize() {
        return normalQueue.size() + emergencyQueue.size();
    }

    void animateVehicleEntry(Circle c) {
        TranslateTransition tt = new TranslateTransition(Duration.seconds(0.5), c);
        tt.setFromX(-20);
        tt.setToX(0);
        tt.play();
    }
    @SuppressWarnings("unused")
    void animateExit(Circle c) {
        Platform.runLater(() -> {
            TranslateTransition tt = new TranslateTransition(Duration.seconds(0.5), c);
            tt.setToX(50);
            tt.setOnFinished(e -> laneBox.getChildren().remove(c));
            tt.play();
        });
    }

    void reset() {
        normalQueue.clear();
        emergencyQueue.clear();
        Platform.runLater(() -> laneBox.getChildren().clear());
    }
}

class TrafficLight {
    int greenTime = 3;
    int redTime = 2;
    int cycleCounter = 0;
    boolean isGreen = true;

    void tick() {
        cycleCounter++;
        if (isGreen && cycleCounter >= greenTime) {
            isGreen = false;
            cycleCounter = 0;
        } else if (!isGreen && cycleCounter >= redTime) {
            isGreen = true;
            cycleCounter = 0;
        }
    }
}

public class TrafficSimulator extends Application {
    static Map<String, Intersection> intersections = new LinkedHashMap<>();
    static Random rand = new Random();
    static int vehicleId = 1;
    static int tickCount = 0;

    Timeline timeline;
    Map<String, Label> queueLabels = new HashMap<>();
    Map<String, Label> statsLabels = new HashMap<>();

    XYChart.Series<Number, Number> seriesA = new XYChart.Series<>();
    XYChart.Series<Number, Number> seriesB = new XYChart.Series<>();
    XYChart.Series<Number, Number> seriesC = new XYChart.Series<>();

    public static void main(String[] args) {
        for (String name : List.of("A", "B", "C")) {
            intersections.put(name, new Intersection(name));
        }
        launch(args);
    }
    @SuppressWarnings("unused")
    @Override
    public void start(Stage stage) {
        VBox root = new VBox(10);
        HBox allLanes = new HBox(20);

        for (String name : intersections.keySet()) {
            VBox box = new VBox(5);
            Label title = new Label("Intersection " + name);
            Rectangle light = new Rectangle(20, 20, Color.GREEN);
            Label queue = new Label("Queue: 0");
            Label stats = new Label("Cleared: 0 | Emergencies: 0");

            queueLabels.put(name, queue);
            statsLabels.put(name, stats);

            Intersection i = intersections.get(name);
            box.getChildren().addAll(title, light, queue, stats, i.laneBox);
            allLanes.getChildren().add(box);
        }

        NumberAxis xAxis = new NumberAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Ticks");
        yAxis.setLabel("Queue Size");

        LineChart<Number, Number> lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setTitle("Live Queue Trends");
        seriesA.setName("A");
        seriesB.setName("B");
        seriesC.setName("C");
        lineChart.getData().add(seriesA);
        lineChart.getData().add(seriesB);
        lineChart.getData().add(seriesC);
        lineChart.setMinHeight(250);

        Button startBtn = new Button("Start");
        Button stopBtn = new Button("Stop");
        Button resetBtn = new Button("Reset");
        HBox controls = new HBox(10, startBtn, stopBtn, resetBtn);

        root.getChildren().addAll(allLanes, controls, lineChart);

        Scene scene = new Scene(root, 800, 600);
        stage.setScene(scene);
        stage.setTitle("Asynchronous Traffic Simulation");
        stage.show();

        timeline = new Timeline(new KeyFrame(Duration.seconds(2), e -> runTick()));
        timeline.setCycleCount(Timeline.INDEFINITE);

        startBtn.setOnAction(e -> timeline.play());
        stopBtn.setOnAction(e -> timeline.stop());
        resetBtn.setOnAction(e -> {
            timeline.stop();
            tickCount = 0;
            vehicleId = 1;
            seriesA.getData().clear();
            seriesB.getData().clear();
            seriesC.getData().clear();
            for (String key : intersections.keySet()) {
                intersections.get(key).reset();
                queueLabels.get(key).setText("Queue: 0");
                statsLabels.get(key).setText("Cleared: 0 | Emergencies: 0");
            }
        });
    }

    void runTick() {
        tickCount++;

        // Spawn in one random intersection per tick
        List<String> keys = new ArrayList<>(intersections.keySet());
        String spawnKey = keys.get(rand.nextInt(keys.size()));
        Intersection spawnIntersection = intersections.get(spawnKey);
        boolean isEmergency = rand.nextInt(10) < 2;
        Vehicle v = new Vehicle("V" + vehicleId++, isEmergency, tickCount);
        spawnIntersection.enqueueVehicle(v);

        if (isEmergency) {
            System.out.println("🚨 Emergency Vehicle Arrived at " + spawnKey + ": " + v.id);
        }

        for (String key : intersections.keySet()) {
            Intersection i = intersections.get(key);
            i.trafficLight.tick();

            if (i.trafficLight.isGreen) {
                List<Vehicle> cleared = i.processTraffic();
                int total = Integer.parseInt(statsLabels.get(key).getText().split(":")[1].split("\\|")[0].trim()) + cleared.size();
                int emergencies = Integer.parseInt(statsLabels.get(key).getText().split(":")[2].trim());
                for (Vehicle c : cleared) {
                    if (c.isEmergency) emergencies++;
                }
                statsLabels.get(key).setText("Cleared: " + total + " | Emergencies: " + emergencies);
            }

            queueLabels.get(key).setText("Queue: " + i.getQueueSize());
        }

        seriesA.getData().add(new XYChart.Data<>(tickCount, intersections.get("A").getQueueSize()));
        seriesB.getData().add(new XYChart.Data<>(tickCount, intersections.get("B").getQueueSize()));
        seriesC.getData().add(new XYChart.Data<>(tickCount, intersections.get("C").getQueueSize()));
    }
}
